const Delay = (ms) => new Promise(res => setTimeout(res, ms));

let isKrim = false;

AddRelationshipGroup('whitelist');
AddRelationshipGroup('nonwhitelist');

onNet('semi-wl:setPlayerPVP', (roles) => {
    NetworkSetFriendlyFireOption(true);
    SetCanAttackFriendly(PlayerPedId(), true, true);
	
	if (roles.includes("")) { // Your Criminal Role ID From your discord
		isKrim = true;
	}

    for (let i = 0; i < roles.length; i++) {
        if (roles[i] === "") { // Your Whitelist Role ID From your discord 
            SetPedRelationshipGroupHash(PlayerPedId(), GetHashKey('whitelist'));
            SetEntityCanBeDamagedByRelationshipGroup(PlayerPedId(), false, GetHashKey('nonwhitelist'));
            return;
        }
    }

    SetPedRelationshipGroupHash(PlayerPedId(), GetHashKey('nonwhitelist'));
    SetEntityCanBeDamagedByRelationshipGroup(PlayerPedId(), true, GetHashKey('whitelist'));
    SetEntityCanBeDamagedByRelationshipGroup(PlayerPedId(), false, GetHashKey('nonwhitelist'));
    print("*Polo#9999")
});

exports('HasKrim', () => {
	return isKrim;
});

exports('HasWhitelist', () => {
    if (GetPedRelationshipGroupHash(PlayerPedId()) === GetHashKey('whitelist'))
        return true; else return false;
        print("*Polo#9999")
});

setTick(() => {
    if (GetPedRelationshipGroupHash(PlayerPedId()) !== GetHashKey('whitelist')) {
      DisablePlayerFiring(PlayerPedId(), true);
      DisableControlAction(0, 140, true);
    }
  });