const Config = {} 

Config.GuildId = "" // Server ID
Config.AuthKey = "" // Bot token

Config.WhitelistId = "" // Whitelist Role ID
Config.CriminalId = "" // Criminal Role ID