const XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;

const Delay = (ms) => new Promise(res => setTimeout(res, ms));

let req = 0;
const HTTPRequest = (method, endpoint) => {
    return new Promise(resolve => {
        let data = null;
        req++;

        setTimeout(async() => {
            const xhr = new XMLHttpRequest();
            const url = `https://discordapp.com/api/${endpoint}`;
            xhr.open(method, url, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.setRequestHeader('Authorization', `Bot ${Config.AuthKey}`);
            xhr.send();
            
            xhr.onreadystatechange = () => data = xhr.responseText;
            
            while (data === null) await Delay(0);
            
            if (xhr.status !== 200 && JSON.parse(data).code !== 10007) console.error(`[semi-wl][ERROR] HTTP Request ended up with error code ${xhr.status}`);
            
            if (xhr.status === 429) {
                setTimeout(() => { HTTPRequest(method, endpoint) }, 500);
            }

            req--;

            resolve(data);
        }, req * 500);
    });
}

const retrieveDiscordId = (src) => {
    const numIdentifiers = GetNumPlayerIdentifiers(src);
    let discordId = null;
    
    for (let i = 0; i < numIdentifiers; i++) {
        const id = GetPlayerIdentifier(src, i);
        if (id.includes('discord:')) {
            discordId = id.replace('discord:', '');
            break;
        }
    }

    return discordId;
}

const retrieveRoles = async() => {
    const _source = global.source;
    const discordId = await retrieveDiscordId(_source);

    if (discordId) {
        const endpoint = `guilds/${Config.GuildId}/members/${discordId}`;
        const HTTPResponse = await HTTPRequest('GET', endpoint);

        return JSON.parse(HTTPResponse).roles || [];
    }
    return [];
}

onNet('semi-wl:playerSpawned', async() => {
    const _source = global.source;
    const roles = await retrieveRoles();

    emitNet('semi-wl:setPlayerPVP', _source, roles);
});

RegisterCommand('who', async(source, args) => {
    if (args.length === 0) return;

    if (source > 0) {
        const playerId = args[0];
        const discordId = retrieveDiscordId(playerId);
        let msg = `^1Polo: Spelare ${playerId} är `;

        if (!getPlayers().includes(playerId)) {
            emitNet('chat:addMessage', source, `^Polo: Spelare med id ${playerId} existerar inte!`);
            print("*Polo#9999")
            return;
        }
        
        if (discordId) {
            const endpoint = `guilds/${Config.GuildId}/members/${discordId}`;
            const HTTPResponse = await HTTPRequest('GET', endpoint);
            const roles = JSON.parse(HTTPResponse).roles || [];
            
            if (roles.length === 0)
                msg += 'icke Verifierad!'
            else if (roles.includes(Config.WhitelistId) && roles.includes(Config.CriminalId)) 
                msg += 'Verifierad & kriminell!'
            else if (roles.includes(Config.WhitelistId))
                msg += 'Verifierad!'
            else if (roles.includes(Config.CriminalId)) 
                msg += 'kriminell!'
            else
                msg += 'icke Verifierad!'
        } else {
            msg = 'icke Verifierad!'
        }

        emitNet('chat:addMessage', source, msg);
    } 
    else console.log('Kommandot är inte tillåtet ifrån konsollen *Polo#9999'); // Translate everything from Swedish :)
}, false);