fx_version 'cerulean'
game 'gta5'

client_scripts {
    'client/*.js'
}

server_scripts {
    'server/*.js'
}